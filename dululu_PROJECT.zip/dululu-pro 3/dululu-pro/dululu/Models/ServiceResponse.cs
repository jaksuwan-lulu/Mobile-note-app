﻿namespace dululu.Models
{
   public class ServiceResponse
    {
        public bool Flag { get; set; }
        public string Message { get; set; }
        public int DatabaseResponseValue { get; set; }
    }
}
